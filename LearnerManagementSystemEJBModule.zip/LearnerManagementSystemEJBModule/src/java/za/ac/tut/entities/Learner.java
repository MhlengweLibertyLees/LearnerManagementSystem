package za.ac.tut.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Learner implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "StudentNumber", nullable = false)
    private String studentNumber;

    @Column(name = "FirstName", nullable = false, length = 40)
    private String firstName;

    @Column(name = "LastName", nullable = false, length = 40)
    private String lastName;

    @Temporal(TemporalType.DATE)
    @Column(name = "DateOfBirth", nullable = false)
    private Date dateOfBirth;

    @Column(name = "Qualification", nullable = false, length = 40)
    private String qualification;

    public Learner() {}

    public Learner(String studentNumber, String firstName, String lastName, Date dateOfBirth, String qualification) {
        this.studentNumber = studentNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.qualification = qualification;
    }

    // Getters and Setters
    public String getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    @Override
    public int hashCode() {
        return (studentNumber != null ? studentNumber.hashCode() : 0);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Learner)) {
            return false;
        }
        Learner other = (Learner) object;
        return (this.studentNumber != null && this.studentNumber.equals(other.studentNumber));
    }

    @Override
    public String toString() {
        return "za.ac.tut.entities.Learner[ studentNumber=" + studentNumber + " ]";
    }
}
